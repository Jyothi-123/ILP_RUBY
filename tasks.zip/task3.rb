
  OPERATORS = ('+' '-' '*' '/' '**')

  def initialize1(expression)
    @elements = expression.split
    @arr = Array.new

	puts  @elements
  end
  def perform_action
    @elements.each do |element|
      if OPERATORS.include? element
        calculate(element) 
      else
        @arr.push(element.to_i)
      end 
    end 
  end

  def calculate(operator)
    operands = @arr.pop(2)
    result = operands.inject(operator)
    @arr.push(result)
   puts @arr
  end
 
puts initialize1("5 1 2 + 4 * + 3 -")
