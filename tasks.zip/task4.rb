
def mix(s1, s2)
	x = ('a'..'z').to_a.select { |letter| s1.count(letter)> 1 || s2.count(letter) > 1 }
	puts x
	x.map! do |x|
	if s1.count(x) > s2.count(x)
	"1:#{x * s1.count(x)}"
	elsif s1.count(x) < s2.count(x)
	"2:#{x * s2.count(x)}"
	else
	"=:#{x * s1.count(x)}"
	end
	end
	x.sort_by { |y| [-y.size, y[0], y[-1]] }.join("/")
end

puts mix("my&friend&Paul has heavy hats! &", "my friend John has many many friends &")
